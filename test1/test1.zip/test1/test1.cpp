﻿

#include <bangtal.h>
#include <windows.h> 

SceneID scene1 = createScene("버튼은 왜 있는 걸까요", "배경.png");
SceneID scene2 = createScene("트루엔딩", "트루.png");
ObjectID light1 = createObject("꺼짐.png");
ObjectID light2 = createObject("꺼짐.png");
ObjectID light3 = createObject("꺼짐.png");
ObjectID light4 = createObject("꺼짐.png");
ObjectID button1 = createObject("열림.png");
ObjectID button2 = createObject("열림.png");
ObjectID button3 = createObject("열림.png");
ObjectID button4 = createObject("열림.png");
ObjectID door = createObject("문.png");
ObjectID key = createObject("키.png");

int a = 0;

void fail() {
	setObjectImage(button1, "열림.png");
	setObjectImage(button2, "열림.png");
	setObjectImage(button3, "열림.png");
	setObjectImage(button4, "열림.png");
	setObjectImage(light1, "꺼짐.png");
	setObjectImage(light2, "꺼짐.png");
	setObjectImage(light3, "꺼짐.png");
	setObjectImage(light4, "꺼짐.png");
	a = 0;
}

void clear() {
	locateObject(door, scene1, 880, 260);
	scaleObject(door, 0.5f);
	showObject(door);
}

void mousecallback1(ObjectID object, int x, int y, MouseAction action)
{
	if (object == door) {
	endGame();
	}
	else if (object == button4) {
		if (a == 0) {
			setObjectImage(button4, "닫힘.png");
			setObjectImage(light1, "켜짐.png");
			a = 1;
		}
		else {
			fail();
		}
	}
	else if (object == button2) {
		if (a == 1) {
			a = 2;
		}
		else if (a == 2) {
			a = 3;
		}
		else if (a == 3) {
			setObjectImage(button2, "닫힘.png");
			setObjectImage(light2, "켜짐.png");
			a = 4;
		}
		else if (a == 5) {
			a = 6;
		}
		else if (a == 6) {
			a = 7;
		}
		else if (a == 7) {
			setObjectImage(button2, "닫힘.png");
			setObjectImage(button3, "닫힘.png");
			setObjectImage(light4, "켜짐.png");
			clear();
		}
		else {
			fail();
		}
	}
	else if (object == button1) {
		if (a == 4) {
			setObjectImage(button1, "닫힘.png");
			setObjectImage(button2, "열림.png");
			setObjectImage(light3, "켜짐.png");
			a = 5;
		}
		else {
			fail();
		}
	}
	else if (object == button3) {
		if (a == 5) {
			a = 6;
		}
		else if (a == 6) {
			a = 7;
		}
		else if (a == 7) {
			setObjectImage(button2, "닫힘.png");
			setObjectImage(button3, "닫힘.png");
			setObjectImage(light4, "켜짐.png");
			clear();
		}
		else {
			fail();
		}
	}
	else if (object == key) {
		enterScene(scene2);
		Sleep(1000);
		endGame();
	}
}

int main()
{
	setMouseCallback(mousecallback1);
	locateObject(light1, scene1, 330, 440);
	locateObject(light2, scene1, 460, 440);
	locateObject(light3, scene1, 590, 440);
	locateObject(light4, scene1, 720, 440);
	scaleObject(light1, 0.15f);
	scaleObject(light2, 0.15f);
	scaleObject(light3, 0.15f);
	scaleObject(light4, 0.15f);

	locateObject(button1, scene1, 120, 83);
	locateObject(button2, scene1, 380, 83);
	locateObject(button3, scene1, 640, 83);
	locateObject(button4, scene1, 900, 83);
	scaleObject(button1, 0.25f);
	scaleObject(button2, 0.25f);
	scaleObject(button3, 0.25f);
	scaleObject(button4, 0.25f);

	showObject(light1);
	showObject(light2);
	showObject(light3);
	showObject(light4);
	showObject(button1);
	showObject(button2);
	showObject(button3);
	showObject(button4);

	locateObject(key, scene1, 1, 500);
	showObject(key);

	startGame(scene1);
}

